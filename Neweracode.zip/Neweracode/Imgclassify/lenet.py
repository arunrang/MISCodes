# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
from keras.models import Sequential
from keras.layers import Convolution2D
from keras.layers import MaxPooling2D
from keras.layers import Flatten
from keras.layers import Dense
class mymodel:
    @staticmethod
    def build(height,width,depth,classes):
        classifier=Sequential()
        
        classifier.add(Convolution2D(32,3,3,input_shape=(height,width,depth),activation='relu'))
        classifier.add(MaxPooling2D(pool_size=(2,2)))
        
        classifier.add(Flatten())
        classifier.add(Dense(output_dim=128,activation='relu'))
        classifier.add(Dense(output_dim=classes,activation='softmax'))
        
        return classifier